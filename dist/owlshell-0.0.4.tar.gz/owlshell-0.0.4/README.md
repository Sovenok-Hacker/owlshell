# owlshell
A Python libary to use OS functions and see an ASCII ART OWL!
Link on PyPI:
https://pypi.org/project/owlshell/
